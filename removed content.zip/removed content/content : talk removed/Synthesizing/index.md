---
abstract: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis posuere tellusac
  convallis placerat. Proin tincidunt magna sed ex sollicitudin condimentum. Sed ac
  faucibus dolor, scelerisque sollicitudin nisi. Cras purus urna, suscipit quis sapien
  eu, pulvinar tempor diam.
all_day: false
authors: []
date: "2030-06-01T13:00:00Z"
date_end: "2030-06-01T15:00:00Z"
event: academia Theme Conference
event_url: https://example.org
featured: false
image:
  caption: 'Image credit: [**Unsplash**](https://unsplash.com/photos/bzdhc5b3Bxs)'
  focal_point: Right
links: null
location: London, United Kingdom
math: true
projects: null
publishDate: "2017-01-01T00:00:00Z"
slides: null
summary: An example talk using academia's Markdown slides feature.
tags: []
title: Synthesizing Qualitative Data
url_code: ""
url_pdf: ""
url_slides: ""
url_video: ""
---

{{% alert note %}}
Click on the **Slides** button above to view the built-in slides feature.
{{% /alert %}}

Slides can be added in a few ways:

- **Create** slides using academia's [*Slides*](https://sourcethemes.com/academic/docs/managing-content/#create-slides) feature and link using `slides` parameter in the front matter of the talk file
- **Upload** an existing slide deck to `static/` and link using `url_slides` parameter in the front matter of the talk file
- **Embed** your slides (e.g. Google Slides) or presentation video on this page using [shortcodes](https://sourcethemes.com/academic/docs/writing-markdown-latex/).

Further talk details can easily be added to this page using *Markdown* and $\rm \LaTeX$ math code.
